# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.


class UserProfile(models.Model):
	chinese_name = models.CharField(max_length=200)
	english_name = models.CharField(max_length=200)
	username = models.CharField(max_length=200)
	password1 = models.CharField(max_length=500)
	password2 = models.CharField(max_length=500)
	gender = models.CharField(max_length=20)
	birth = models.CharField(max_length=100,help_text="1911-01-01")
	number = models.CharField(max_length=200)
	home_number = models.CharField(max_length=200)
	address = models.CharField(max_length=200,default="Your home address")
	email = models.EmailField(max_length=200,default="xxx@gmail.com")
	def __unicode__(self):
		return self.username